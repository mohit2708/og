<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class RouteList extends Model
{
    protected $table = 'tbl_route_tables_info';
    protected $primarykey = 'id';
}
