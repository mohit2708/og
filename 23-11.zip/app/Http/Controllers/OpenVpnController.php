<?php
namespace App\Http\Controllers;
use Illuminate\Http\Request;
use App\Mail\FileDownloaded;
use Illuminate\Support\Facades\Storage;
use Illuminate\Support\Facades\Response;
use File;
use App\OpenVpnConfig;

class OpenVpnController extends Controller
{
    public function index(Request $request)
    {	
    	return view('open_vpn');     
    }

    public function exportData(Request $request)
    {

      // $post = new OpenVpnConfig;
      // $post->destination = $request->input('destination');
      // $post->gateway     = $request->input('gateway');
      // //$post->metric      = $request->input('metric');
      // $post->save();

      //$data = $request->description;
      $data = "Device Serial Information";

      $fileName = time() . '_device-serial.conf'; 
      $filepath = File::put(public_path('/device_serial_files/'.$fileName),$data);
      //dd($filepath);
      //return Response::download(public_path('/device_serial_files/'.$fileName));  
      return redirect('open-vpn')->with('success', 'File Download successfully');
    

      
  }
}
