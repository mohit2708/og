<?php

namespace App;

use Illuminate\Database\Eloquent\Model;
//use Illuminate\Database\Eloquent\SoftDeletes;

class RouteOperation extends Model
{
//use SoftDeletes;
    protected $table = 'tbl_operation_on_route';

     /**
     * The attributes that are mass assignable.
     *
     * @var array
     */
    protected $fillable = [
        'ip_address',
		'tunnel_ip',
		'device_serial',
		'network_type',
		'route_option',
		'netmask_value',
    ];
}