
"use strict";

// $('.toggleIcon').click(function(){
//   $('#leftmenusection').toggleClass('openmenu mobilemenuopen');
//   $('#rightContentPanel').toggleClass('fullContentPanel');
//   $('#TopHeader').toggleClass('fullheader');
// });


