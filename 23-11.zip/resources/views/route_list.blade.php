@extends('layouts.app')
@section('content')
<div class="main-content">
                <div class="section__content section__content--p30">
                    <div class="container-fluid">
                     <div class="row m-t-30">
                            <div class="col-md-12">
                                <!-- DATA TABLE-->
                                <h3 class="title-5 m-b-35">Route List</h3>
                                <div class="table-responsive m-b-40">
                            <div class="table-title">
                             <div class="row">
                                <div class="col-sm-6">
                                   <form class="form-inline my-2 my-lg-0" action="{{url('route-list')}}" method="GET">
                                  <input class="form-control" type="search" name="q" placeholder="Device Serial Number"> &nbsp;
                                  <button type="submit" class="btn btn-primary">Search</button>
                                 
                              </form><br> 
                                </div>
                                <div class="col-sm-3">
                                </div>
                                <div class="col-sm-3"> 
                                  <a href="#addEmployeeModal" class="btn btn-success" data-toggle="modal"><i class="fa fa-plus"></i><span>Add New Route</span></a>  

                                  <!-- <a href="javascript:void(0)" class="btn btn-success" id="new-customer" data-toggle="modal"><i class="fa fa-plus"></i> <span>Add New Route</span></a> -->
                                </div>
                             </div>
                          </div>
                                    <table class="table table-borderless table-data3">
                                        <thead>
                                            <tr>
                                                <th>Device Serial Number</th>
                                                <th>Destination</th>
                                                <th>Gateway</th>
                                                <th>Genmask</th>
                                                <th>Flags</th>
                                                <th>Metric</th>
                                                <th>Ref</th>
                                                <th>T Use</th>
                                                <th>I Face</th>                                                
                                                <th>Action</th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                          @foreach($roulelists as $roulelist)
                                            <tr>
                                                <td>{{$roulelist->device_serial}}</td>
                                                <td>{{$roulelist->destination}}</td>
                                                <td>{{$roulelist->gateway}}</td>
                                                <td>{{$roulelist->genmask}}</td>
                                                <td>{{$roulelist->flags}}</td>
                                                <td>{{$roulelist->metric}}</td>
                                                <td>{{$roulelist->ref}}</td>
                                                <td>{{$roulelist->t_use}}</td>
                                                <td>{{$roulelist->iface}}</td>
                                                <td><a href="#addEmplodyeeModal" class="btn btn-success" data-toggle="modal"><span>Delete</span></a></td>          
                                            </tr>
                                            @endforeach                                  
                                        </tbody>
                                    </table>
                                </div>
                                <!-- END DATA TABLE-->
                            </div>
                        </div>                        
                    </div>
                </div>
            </div>
<!-- Delete Modal HTML -->
  <div id="delete_confirm" class="modal fade" role="dialog">
  <div class="modal-dialog">
    <div class="modal-content">         
        <div class="modal-header">            
          <h4 class="modal-title">Delete User</h4>
          <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
        </div>
        <div class="modal-body">          
          <p>Are you sure you want to delete these Records?</p>         
        </div>
        <div class="modal-footer">
          <input type="button" class="btn btn-default" data-dismiss="modal" value="Cancel">
          <span id="delete_butt_id"></span>
        </div>      
    </div>
  </div>
</div>
<!-- Edit Modal HTML -->
<div id="addEmployeeModal" class="modal fade">
  <div class="modal-dialog">
    <div class="modal-content">
      <form action ="{{url('route-opertion/store')}}" method="POST">
       
        {!! csrf_field() !!}
        <div class="modal-header">            
          <h4 class="modal-title">Add New Route</h4>
          <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
        </div>
        <div class="modal-body">          
          <div class="form-group">
            <label>IP Address</label>
            <input type="text" class="form-control @error('network') is-invalid @enderror" id="ip_address" name="ip_address" placeholder="Enter Your IP Address" value="{{ old('ip_address') }}">
             @error('ip_address')
             <span class="invalid-feedback" role="alert">
             <strong>{{ $message }}</strong>
             </span>
             @enderror
          </div>
          <div class="form-group">
            <label>NetMask</label>
            <input type="text" class="form-control @error('netmask_value') is-invalid @enderror" id="netmask_value" name="netmask_value" placeholder="NetMask Value" value="{{ old('netmask_value') }}">
             @error('netmask_value')
             <span class="invalid-feedback" role="alert">
             <strong>{{ $message }}</strong>
             </span>
             @enderror
          </div>

            <div class="form-group">
              <label>Device Serial Number</label>
              <select class="form-control @error('network') is-invalid @enderror" id="device_serial_number" name="device_serial_number">
                 <option value="" disabled selected>-- Select Serial Number --</option>
                 @foreach($showdeviceinfo as $dinfo)
                 <option value="{{$dinfo->device_serial}}">{{$dinfo->device_serial}}</option>
                 @endforeach  
              </select>
              @error('device_serial_number')
              <span class="invalid-feedback" role="alert">
              <strong>{{ $message }}</strong>
              </span>
              @enderror
           </div>

           <div class="form-group">
              <label>Tunnel IP</label>
              <input type="text" class="form-control" id="tunnel_ip" name="tunnel_ip" readonly>
           </div>
          
          
          <div class="form-group">
            <label>Network</label>
            <select class="form-control @error('network') is-invalid @enderror" id="network" name="network">
               <option value="" disabled selected>-- Select Network --</option>
               <option value="LTE">LTE</option>
               <option value="WAN">WAN</option>
            </select>
            @error('network')
            <span class="invalid-feedback" role="alert">
            <strong>{{ $message }}</strong>
            </span>
            @enderror
          </div>
          <div class="form-group">
            <label>Route Option</label>
            <select class="form-control @error('route_option') is-invalid @enderror" id="route_option" name="route_option">
               <option value="" disabled selected>-- Select Route Option --</option>
               <option value="Add">Add</option>
               <option value="Delete">Delete</option>
            </select>
            @error('route_option')
            <span class="invalid-feedback" role="alert">
            <strong>{{ $message }}</strong>
            </span>
            @enderror
         </div>
          <!-- <div class="form-group">
            <label>Phone</label>
            <input type="text" class="form-control" required>
          </div> -->          
        </div>
        <div class="modal-footer">
          <input type="button" class="btn btn-default" data-dismiss="modal" value="Cancel">         
          <button type="submit" class="btn btn-primary btn-sm">Submit</button>
        </div>
      </form>
    </div>
  </div>
</div>

@endsection