@extends('layouts.app')
@section('content')
<div class="main-content">
                <div class="section__content section__content--p30">
                    <div class="container-fluid">
                           <div class="row m-t-30">
                              <div class="col-lg-12">
                                <h3 class="title-5 m-b-35">IP Table</h3>
                                  
                               
                                

                            </div>
                        </div>                        
                    </div>
                </div>
            </div>
@endsection