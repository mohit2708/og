@extends('layouts.app')
@section('content')
<div class="main-content">
                <div class="section__content section__content--p30">
                    <div class="container-fluid">
                           <div class="row m-t-30">
                              <div class="col-lg-12">
                                <h3 class="title-5 m-b-35">Open VPN</h3>
                                  @if ($message = Session::get('success'))
                                <div class="alert alert-success alert-block">
                                  <button type="button" class="close" data-dismiss="alert">×</button> 
                                        <strong>{{ $message }}</strong>
                                </div>
                                @endif
                                <form method="POST" action="{{ url('export-file') }}" enctype="multipart/form-data">
                                {!! csrf_field() !!}
                                <!-- <p name="description">MIIDQjCCAiqgAwIBAgIUCf34pjKjA9KbCN2C22s2J1EuPnMwDQYJKoZIhvcNAQEL
                                BQAwEzERMA8GA1UEAwwIQ2hhbmdlTWUwHhcNMjAxMDI4MTEwNjQwWhcNMzAxMDI2
                                MTEwNjQwWjATMREwDwYDVQQDDAhDaGFuZ2VNZTCCASIwDQYJKoZIhvcNAQEBBQAD
                                ggEPADCCAQoCggEBAMZdhdQOiF4p08k1t7XNfrfhIdasSVkVEsnmK1FQGd1yynpp
                                l0eGboAjYr6DYqwmzt4/lebzlPMmAtC9UcgOZrOpIL5Jed+LU319EzP66ytfGr+Y
                                nY/1fso0bkKilgkKrqE+XeJC7IMgAmrI3B8Yz28rVjHCfciSy/+S+WdoGGe2YNTm
                                aEl/pxl7eaBHPKjWYibU3F5B42GLE3/i+yYPkvJi6ijZkgGW+mNcKRQI6R1NAiQT
                                6yZuDFkpzq79NQjIa1Kh4M2qGkF9mIkr3QqKCHq50ihuH698thyMQHwCBNcBgITp
                                SBhzU/kpED4tgbcN+FsA1jnNVrJ2KFrDUfTPwf0CAwEAAaOBjTCBijAdBgNVHQ4E
                                FgQUTO7kQvvrrsoiJqnyrsM9+riLUDIwTgYDVR0jBEcwRYAUTO7kQvvrrsoiJqny
                                rsM9+riLUDKhF6QVMBMxETAPBgNVBAMMCENoYW5nZU1lghQJ/fimMqMD0psI3YLb
                                azYnUS4+czAMBgNVHRMEBTADAQH/MAsGA1UdDwQEAwIBBjANBgkqhkiG9w0BAQsF
                                AAOCAQEASSFe+dKdyKXFsbue82COK+ZXINIBnkGS5QpdZImPI2vy9Y99jTVTAMh0
                                +IJGyCSNHhUkZdbO+ibPkI7eoVgHMh1iO6uPfP+PwY5s4UylP3ghRJiu2OrRrHjv
                                CkKTUW1BvgY8hlfHSY4NUDj8BV5QcAqAPv7IQiQ+XRUT8Wbbes13Zdc6mUeT5/eq
                                1i3XzQzbFCg/dE0mKNllESjHqQZraV8eKgqWdcGiv91yvpW42JfaDGfPIr6JXCz9
                                s4qBkDLfPmhbNft/3qb2MYYmfqqxUJkcEgU3ZpWcjshYsZXS/mY1FJxet+7tgLw7
                                KMDAIcqbaqJTrC3U07DLimJ5nvEZ2w==</p> -->

 <!--  <textarea name="description">
    Write something.
  </textarea> -->
<br>
<div class="row">
  <div class="col-md-9">
  </div>
  <div class="col-md-3">
    <button type="submit" class="btn btn-primary">File Export</button>
  </div>
  </div>
  
</form>

                            </div>
                        </div>                        
                    </div>
                </div>
            </div>
@endsection